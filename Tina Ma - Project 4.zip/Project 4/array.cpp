﻿#include <iostream>
#include <string>
#include <cassert>
using namespace std;

int reduplicate(string a[], int n) { //For each of the n elements of the array, append element to itself

	int size = a->size();

	if (size < 0 || n < 0 ) { //bad arguments; negative array size or a position that would require looking at the contents of an element past the last element we're interested in
		return -1;
	}
	else {
		for (int i = 0; i < n; i++) {
			a[i] = a[i] + a[i];
		}
	}
	
	return n; 
}

int locate(const string a[], int n, string target) {
	//Return the position of a string in the array that is equal to target
	//if there is more than one such string, return the smallest position number of such a matching string

	if (n < 0) { 
		return -1;
	}
	else {
		for (int i = 0; i < n; i++) {
			if (target == a[i]) {
				return i;
			}
		}
	}

	return -1; // if no such string, return -1. 
}


int locationOfMax(const string a[], int n) { //return position of a string in the array such that string is >= every string
	bool loop;

	if (n <= 0)
		return (-1);
	else {
		for (int i = 0; i < n; i++) {       //compares each element with other elements one by one
			loop = true;

			for (int j = 0; j < n; j++){
				if (!(a[i] >= a[j])) //if ith element is smaller than j'th element, stop. 
					loop = false;
			}

			if (loop == true)
				return (i);
		}
		return(520);   //just to appease g++ (will never run b/c there's min. of 1 array element)
	}
}


int circleLeft(string a[], int n, int pos) { //shift every element to the left; move first element to end

	if (n <= 0 || pos < 0 || pos > n){
		return -1;
	}

	string temp = a[pos]; //temp string to store first element
	int size = a->size() - 1;

	for (int i = pos - 1; i < size - 1; i++) { //for every element in the array
		a[i] = a[i + 1]; //shift to the left
	}

	a[size - 1] = temp; 

	return pos;
}


int enumerateRuns(const string a[], int n) { //Return the number of sequences of one or more consecutive identical items in a.

	int size = a->size();
	int cnt = 0;

	if (n < 0) {
		return -1;
	}
	else if (n == 0) {
		return 0;
	}

	cnt++;

	for (int i = 1; i < size; i++) {
		if (a[i] != a[i - 1]) { //if equal to the last one, don't increase cnt. 
			cnt++;
		}
	}

	return cnt;
}


int flip(string a[], int n) { //flip values in array
	
	int size = a->size();

	if (n < 0 || size < 0) {
		return -1;
	}

	int end = n - 1; //subtract 1 from n because array indexes start at 0.

	for (int i = 0; i < n/2; i++) {
		swap(a[i], a[end]);
		end--;
	}

	return n;

}
int locateDifference(const string a1[], int n1, const string a2[], int n2) {

	int i, j;

	if (n1 <= 0 || n2 <= 0) {
		return -1;
	}
	
	for (i = 0; i < n1; i++) {
		if (a1[i] != a2[i]) {
			return i;
		}
	}

	return min(n1, n2);

}

int subsequence(const string a1[], int n1, const string a2[], int n2) {

	if (n1 < 0 || n2 < 0) {
		return -1;
	}

	if (n2 == 0) {
		return 0;
	}
	int subInt = 0;

	for (int i = 0; i < n1; i++) {
		if (a1[i] == a2[subInt]) {
			subInt++;
			if (subInt == n2) {
				return (i - n2 + 1); //
			}
		}
	}
	
	return -1;
}


int locateAny(const string a1[], int n1, const string a2[], int n2) {

	int minIndex;

	if (n1 <= 0 || n2 < 0) {
		return -1;
	}

	if (n2 == 0) {
		return 0;
	}

	for (int i = 0; i < n1; i++) {
		for (int j = 0; j < n2; j++) {
			if (a1[i] == a2[j]) {
				return i;
			}
		}
	}

}

int separate(string a[], int n, string separator) {
	
	string temp = "";
	int size = a->size() - 1;

	if (n < 0) {
		return -1;
	}

	for (int i = 0; i < n; i++) { //sort all elements in array in ascending order using bubble sort
		for (int j = 0; j < n - 1; j++) {
			if (a[j] > a[i]) {
				swap(a[i], a[j]);
			}
		}
	}

	for (int index = 0; index < n; index++) {
		if (a[index] >= separator) {
			return (index);
		}
	}

	return n; //return n if there are no such elements
}


int main()
{	
	//reduplicate function
	string c[4] = { "ma", "can", "tu", "do" };
	assert(reduplicate(c, 4) == 4 && c[0] == "mama" && c[3] == "dodo");		//correct return
	assert(reduplicate(c, -4) == -1);										//negative n value
	assert(reduplicate(c, 0) == 0);											//0 items

	//locate function
	string h[8] = { "moana", "mulan", "ariel", "tiana", "", "belle", "elsa", "ariel"};
	assert(locate(h, 7, "belle") == 5);			//correct return
	assert(locate(h, 7, "ariel") == 2);			//return smallest value if multiple
	assert(locate(h, 1, "ariel") == -1);		//none found within scope
	assert(locate(h, -3, "hello") == -1);		//negative n value
	assert(locate(h, 0, "hello") == -1);		//no such string

	//locationOfMax funtion
	assert(locationOfMax(h, 7) == 3);			//correct return
	assert(locationOfMax(h, -7) == -1);			//negative n value
	assert(locationOfMax(h, 0) == -1);			//no elements of array to be examined
	string cast[6] = { "elsa", "ariel", "mulan", "tiana", "belle", "tiana" };
	assert(locationOfMax(cast, 6) == 3);		//repeated elements
	
	//circleLeft function
	string g[4] = { "moana", "mulan", "belle", "raya" };
	assert(circleLeft(g, 4, 1) == 1 && g[1] == "belle" && g[3] == "mulan");		//correct return
	assert(circleLeft(g, 4, 5) == -1);											//position greater than n
	assert(circleLeft(g, -4, 1) == -1);											//negative n value
	assert(circleLeft(g, 3, 2) == 2 && g[1] == "raya");							//correct return
	assert(circleLeft(g, 0, 1) == -1);											//n is 0
	
	//locateDifference function
	assert(locateDifference(h, 4, g, 4) == 0);			//correct return of 0
	assert(locateDifference(h, -4, g, 4) == -1);		//negative n1 value
	assert(locateDifference(h, 4, g, -4) == -1);		//negative n2 value
	assert(locateDifference(h, 4, g, 0) == -1);			//0 element array
	assert(locateDifference(h, 0, g, 4) == -1);			//0 element array
	string roles[6] = { "merida", "raya", "", "belle", "moana", "elsa" };
	string group[5] = { "merida", "raya", "elsa", "", "belle" };
	assert(locateDifference(roles, 6, group, 5) == 2);	//correct return 
	assert(locateDifference(roles, 2, group, 1) == 1);	//correct return

	//subsequence function
	string e[4] = { "ariel", "tiana", "", "belle" };
	assert(subsequence(h, 7, e, 4) == 2);				//correct return
	assert(subsequence(h, 1, e, 4) == -1);				//a1 does not contain a2
	assert(subsequence(h, 0, e, 4) == -1);				//sequence of 0 for a1[]
	assert(subsequence(h, 3, e, 0) == 0);				//sequence of 0 for a2[]
	assert(subsequence(h, 0, e, 0) == 0);				//sequence of 0 for both

	//enumerateRuns function
	string d[5] = { "mulan", "mulan", "mulan", "belle", "belle" };
	assert(enumerateRuns(d, 5) == 2);			//correct return
	assert(enumerateRuns(d, 0) == 0);			//no items; no unique objects
	assert(enumerateRuns(d, -3) == -1);			//negative n value

	//locateAny function
	string f[3] = {"tiana", "ariel", "raya"};
	assert(locateAny(h, 7, f, 3) == 2);			//correct return
	assert(locateAny(h, 0, f, 3) == -1);		//sequence of 0 for n1
	assert(locateAny(h, 7, f, 0) == 0);			//sequence of 0 for n2
	string u[2] = { "", "ariel" };
	assert(locateAny(h, 7, f, 2) == 2);			//multiple matches
	assert(locateAny(h, -3, f, 3) == -1);		//negative n1 value
	assert(locateAny(h, 3, f, -4) == -1);			//negative n2 value

	//flip function
	assert(flip(f, 3) == 3 && f[0] == "raya" && f[2] == "tiana");	//correct return
	assert(flip(f, 0) == 0);							//correct return
	assert(flip(f, -2) == -1);							//negative n value

	//separate function
	assert(separate(h, 7, "elsa") == 3);		//correct return
	assert(separate(h, 0, "elsa") == 0);		// no elements
	assert(separate(h, 4, "zzzzzzfaihkahkfja") == 4); //return n; no such elements

	

	cout << "All tests succeeded" << endl;
}