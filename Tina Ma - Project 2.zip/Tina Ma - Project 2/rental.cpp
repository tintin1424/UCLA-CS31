//  main.cpp
/*
Tina Ma
Oct 14 2021
CS31 Project 2
*/


#include <iostream>
#include <string>

using namespace std;

int main() {

    //declaring variables
    int odoStart;
    int odoEnd;
    int days;
    string name;
    string luxury;
    int month;


    //taking in data
    cout << "Odometer at start: ";
    cin >> odoStart;
    if (odoStart < 0) {
        cout << endl << "---" << endl;
        cout << "The starting reading must a nonnegative integer." << endl;
        return 1;
    }

    cout << "Odometer at end: ";
    cin >> odoEnd;
    if (odoEnd < odoStart)
    {
        cout << endl << "---" << endl;
        cout << "The final reading must be greater than the starting reading." << endl;
        return 1;
    }

    cout << "Rental days: ";
    cin >> days;
    if (days <= 0)
    {
        cout << endl << "---" << endl;
        cout << "The number of rental days must be positive." << endl;
        return 1;
    }

    cout << "Customer name: ";
    getline(cin, name);
    if (name == "") {
        cout << endl << "---" << endl;
        cout << "You must enter a customer name." << endl;
        return 1;
    }

    cout << "Luxury car? (y/n): ";
    cin >> luxury;
    if (luxury != "y" && luxury != "n")
    {
        cout << endl << "---" << endl;
        cout << "You must enter y or n." << endl;
        return 1;
    }

    cout << "Month (1=Jan, 2=Feb, etc.): ";
    cin >> month;
    if (month > 12 || month < 1)
    {
        cout << endl << "---" << endl;
        cout << "The month number must be in the range 1 through 12." << endl;
        return 1;
    }


    //calculating the total charge

    cout.setf(ios::fixed);
    cout.precision(2);

    int milesTot = odoEnd - odoStart;
    int baseCharge;
    double rate;
    double charge;

    int milesLeft = milesTot;

    //depending on the model of the car, the charge per day is $43 for non-luxury and $71 for luxury. 
    if (luxury == "y") {
        baseCharge = days * 71;
    }
    else if (luxury == "n") {
        baseCharge = days * 43;
    }


    if (milesTot < 100) { //if more than 100 miles, charge is equal to $0.17 per mile. 
        rate = 0.17;
        charge = baseCharge + milesTot * rate;
        milesLeft = 0;

    }

    if ((milesTot <= 500) && (milesTot > 100)) {

        milesLeft = milesTot - 100;

        if (month == 12 || month <= 3) {
            rate = 0.27;
        }
        else {
            rate = 0.21;
        }

        charge = charge + (milesLeft * rate);
    }
    else if (milesTot > 500) {
        rate = 0.17;

        milesLeft = milesTot - 500;
        charge = baseCharge + (milesLeft * rate);
    }


    //output: 
    cout << "---" << endl;
    cout << "The rental charge for " << name << " is $" << charge << endl;
    return 0;
}