#pragma warning(disable:6262)
#define _CRT_SECURE_NO_DEPRECATE

#include <iostream>
#include <string>
#include <cstring>
#include <cctype>
#include <cassert>
using namespace std;


//-------------------------------------FUNCTIONS-------------------------------------

void lowercase(char text[]) { //changes entire text message to lowercase
    for (int i = 0; text[i] != '\0'; i++) { //iterate through all letters; use tolower() to overwrite each index of array
        text[i] = tolower(text[i]);
    }
}

void uppercase(char text[]) { //changes entire ciphertext message to uppercase
    for (int i = 0; text[i] != '\0'; i++) { //iterate through all letters; use toipper() to overwrite each index of array
        text[i] = toupper(text[i]);
    }
}

void clean(char text[]) {   //given text, creates 2D array cleanText for full ciphertext message; populates 2D array without non-letter characters. each message will be 90 characters maximum. 
    int head = 0;
    for (int i = 0; i < strlen(text); i++) { //loop through every item in text
        if (isalpha(text[i])) { //if character is alphabetical
            text[head] = text[i]; //copy items into text
            head++;
        }
        else if (head > 0) { //otherwise, 
            while (!isalpha(text[i + 1])) { //if character is not in the alphabet, increment i without copying into array
                i++;
            }
            if (i < strlen(text) - 1) { //if reached the end, 
                text[head] = ' ';
                head++;
            }
        }
    }
    for (int i = head; i < strlen(text); i++) { //fill in rest of string with null characters
        text[i] = '\0';
    }
}


void output(char cipher[], char plaintocipher[]) { //output will print out the partially decrypted messages
    for (int i = 0; i < strlen(cipher); i++) //loop through every item in cipher
    {
        for (int j = 0; j < 27; j++) //for every item in plaintocipher array, 
        {
            if (plaintocipher[j] == '\0') //if item is null, continue
                continue;

            if (cipher[i] == plaintocipher[j]) //otherwise, if they are equal, 
            {
                cipher[i] = plaintocipher[j];    // translates ciphertext. break
                break;
            }
        }
    }
    cout << cipher;    // prints translated message
}
//-------------------------------------DECRYPT-------------------------------------

bool decrypt(const char ciphertext[], const char crib[]) {

    // make a clean and lowercase copy of the crib
    char cribCopy[strlen(crib)];
    strcpy(cribCopy, crib);
    clean(cribCopy);
    lowercase(cribCopy);

    if (strlen(cribCopy) > strlen(ciphertext) || strlen(cribCopy) > 90 || strlen(cribCopy) == 0) {    //if crib is longer than ciphertext
        return false;
    }

    // cout << "Crib: " << cribCopy << '\n'; //for testing

    // split the ciphertext into rows
    char cipherCopy[71][91]; //won't be more than 70 rows and 90 columns in any given input
    int row = 0;
    int index = 0;
    for (int i = 0; i < strlen(ciphertext); i++) { //loop through all elements in ciphertext
        if (ciphertext[i] == '\n') {
            row++; //if new line character, move to next line correspondingly
            index = 0;
        }
        else { //otherwise, copy back into ciphertext. 
            cipherCopy[row][index++] = ciphertext[i];
        }
    }

    // make a clean and lowercase copy of each row of the copied ciphertext
    for (int i = 0; i <= row; i++) {
        clean(cipherCopy[i]);
        lowercase(cipherCopy[i]);
        // for (int j = 0; j < strlen(cipherCopy[i]); j++) {
        //     cout << cipherCopy[i][j];
        // }
        // cout << '\n';
    }

    // search for the crib in each row and produce the dictionary

    // initialize dict with '*'
    char dict[26];
    for (int i = 0; i < 26; i++) {
        dict[i] = '*';
    }

    // variable to check if crib has been found
    bool found = false;

    // loop through each row in the ciphertext and search for the crib in each row
    for (int i = 0; i <= row; i++) {

        if (found) {
            break;
        }

        // loop through each letter in the row and search for the crib starting at that letter
        for (int j = 0; j < strlen(cipherCopy[i]) - strlen(cribCopy); j++) {

            if (found) {
                break;
            }

            if (!(j == 0 || cipherCopy[i][j - 1] == ' ')) {
                continue;
            }


            int count = 0;

            // array to check if each char 
            // char check[26];

            // cout << j << " " << strlen(cipherCopy[i] - strlen(cribCopy)) << '\n';


            //for each item in cribCopy, match to original string. 
            for (int k = 0; k < strlen(cribCopy); k++) {
                if (((isalpha(cipherCopy[i][k + j]) && isalpha(cribCopy[k])) || (!isalpha(cipherCopy[i][k + j]) && !isalpha(cribCopy[k]))) && (cipherCopy[i][k + j] == ' ' || dict[cipherCopy[i][k + j] - 'a'] == '*' || dict[cipherCopy[i][k + j] - 'a'] == cribCopy[k])) {
                    if (cipherCopy[i][k + j] != ' ') {
                        dict[cipherCopy[i][k + j] - 'a'] = cribCopy[k];
                    }

                    count++;
                }
            }

            // cout << count << '\n';

            if (count == strlen(cribCopy)) {
                found = true;
                break;
            }
            else {
                for (int i = 0; i < 26; i++) {
                    dict[i] = '*';
                }
            }
        }
    }

    // for (int i = 0; i < 26; i++) {
    //     if (dict[i] != '*')
    //         cout << (char)(i + 'a') << ": " << dict[i] << '\n';
    // }

    char output[strlen(ciphertext)];
    strcpy(output, ciphertext);

    if (found) {
        for (int i = 0; i < strlen(output); i++) {
            if (isalpha(output[i])) {
                if (dict[tolower(output[i]) - 'a'] != '*') {
                    output[i] = toupper(dict[tolower(output[i] - 'a')]);
                }
                else {
                    output[i] = tolower(output[i]);
                }
            }
        }

        for (int i = 0; i < strlen(output); i++) {
            cout << output[i];
        }
        return true;
    }
    else {
        return false;
    }


}


//-------------------------------------MAIN FUNCTION-------------------------------------

void runtest(const char ciphertext[], const char crib[]) {
    cout << "====== " << crib << endl;
    bool result = decrypt(ciphertext, crib);
    cout << "Return value: " << result << endl;
}

int main() {

    cout.setf(ios::boolalpha); // output bools as "true"/"false"

    //runtest("Hirdd ejsy zu drvtry od.\nO'z fodvtrry.\n", "my secret");
    //runtest("Hirdd ejsy zu drvtry od.\nO'z fodvtrry.\n", "shadow");
    char ciphertext[] = "Zysqjs zbguncyqzo jdsbyo eybmnu bg Wqzsvbbf.\nUnysqx eybmgxrsuu ymtbyu kcq Jicjjsy.\nNbuj sajysts rcvsyqr qgx sajysts zbgusykqjcks nbucjcbgu bg xcuzmuucbg wbymtu.\nZU 31 cu zdqrrsgecge!";
    // char ciphertext[] = "My network connection at home was down, and I didn't have a way to copy my files and bring them to a SEASnet machine.";
    char crib[] = { "conspiracy theory" };
    char ciphertext2[] = { "DiebjiggK, zyxZYXzyx--Abca abCa    bdefg## $$hidbijk6437 wvuWVUwvu\n\n8 9\n" };
    char crib2[] = { "   hush???hUSh---     --- until    JanuARY !!  " };
    // char crib[] = {"pwddvpaowd ca"};
     //cout << length(crib);

    //assert(decrypt("My network connection at home was down, and I didn't have a way to copy my files and bring them to a SEASnet machine.", "pwddvpaowd ca"));
    //assert(decrypt(ciphertext, crib));
    //assert(decrypt("Rzy pkr", "dog"));
    //assert(decrypt(ciphertext2, crib2));

}