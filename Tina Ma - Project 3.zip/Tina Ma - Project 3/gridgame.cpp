#include <iostream>
#include <string>
#include "grid.h"
#include <cassert>
using namespace std;

bool isValid(int r, int c) {
	if (r > getRows() || r <= 0 || c > getCols() || c <= 0) {
		return false;
	}

	if (isWall(r, c)) {
		return false;
	}

	return true;
}

bool isValidDirection(char dir) {
	return (dir == 'N' || dir == 'n' || dir == 'E' || dir == 'e' || dir == 'S' || dir == 's' || dir == 'W' || dir == 'w');
}

bool hasCorrectForm(string plan) { // true if its parameter is a plan

	bool hasCorrectForm = true;
	char ch;

	if (plan == "") {
		return true;
	}

	for (int i = 0; i < (int) plan.length(); i++) {
		ch = plan.at(i);

		if (i < (int) plan.length() - 3) { //check for number of consecutive digits. cannot have three consecutive digits in a row.
			if (isdigit(plan.at(i)) && isdigit(plan.at(i + 1)) && isdigit(plan.at(i + 2))) { 
				return false;  //plan cannot have more than two consecutive numbers in a row			
			}
		}

		if (!isdigit(ch) && (ch != 'R' && ch != 'r' && ch != 'L' && ch != 'l')) { //if character is not a digit, and is not one of the direction letters
			return false; //must be false
		}
	}

	if (isdigit(plan.at((int) plan.length() -1))) //plan cannot end in a number
		hasCorrectForm = false;

	return hasCorrectForm;
}

int determineSafeDistance(int r, int c, char dir, int maxSteps) { //determines the number of steps a car starting at position i (r, c) could travel in the direction indicated

	//starting conditions where determineSafeDistance will immediately return -1. 
	if (!isValid(r, c)) { //if (r,c) is not a valid empty grid position
		return -1;
	}
	else if (!isValidDirection(dir)) {
		//if dir is not a direction letter, return -1 
		return -1;
	}
	else if (maxSteps < 0) {
		return -1;
	}

	int newR = r; // newR and newC to original variables
	int newC = c;

	for (int i = 1; i <= maxSteps + 1; i++) {

		if (dir == 'e' || dir == 'E') { //movement East will result in a greater column number. row number stays unchanged. 
			newC++;
		}

		else if (dir == 'w' || dir == 'W') { //movement West will result in a lower column number. row number stays unchanged. 
			newC--;
		}

		else if (dir == 's' || dir == 'S') { //movement South will result in a greater row number. column number stays unchanged. 
			newR++;
		}

		else if (dir == 'n' || dir == 'N') { //movement North will result in a lower column number. row number stays unchanged. 
			newR--;
		}

		if (!isValid(newR, newC)) {
			return (i - 1);
		}
	}

	return maxSteps;
}

int obeyPlan(int sr, int sc, int er, int ec, char dir, string plan, int& nsteps) { //determines number of steps a car starting at position (sr, sc) and initially facing direction dir travels when obeying indicated plan. 

	int newR = sr; //newR and newC are equal to starting r and c
	int newC = sc;
	int steps = 0;//count number of steps you go
	char ch;
	int directionNum;

	if (!isValid(sr, sc) || !isValid(er, ec) || !hasCorrectForm(plan) || !isValidDirection(dir)) {
		return 2; //if (sr,sc) or (er,ec) are not valid empty grid positions or dir is not direction letter or plan string is not a plan, function returns 2, leaves nsteps unchanged
	}

	nsteps = 0;

	//setting direction numbers
	if (dir == 'N' || dir == 'n') {
		directionNum = 0;		
	}
	else if (dir == 'E' || dir == 'e') {
		directionNum = 1;
	}
	else if (dir == 'S' || dir == 's') {
		directionNum = 2;
	}
	else {
		directionNum = 3;
	}

	int skip = 0;

	for (int i = 0; i < plan.size(); i++) {
		if (skip > 0) {
			skip--;
			continue; //skips the current iteration, moves on to next i. 
		}

		ch = plan.at(i);

		if (ch == 'L' || ch == 'l') { //if ch is a direction letter; add or subtract directionNum (add 1 to turn CW or subtract 1 to turn CCW)
			directionNum--;
		}
		else if (ch == 'R' || ch == 'r') {
			directionNum++;
		}

		directionNum %= 4;

		if (directionNum == 0) { //change direction variable to correct direction accordingly
			dir = 'N';
		}
		else if (directionNum == 1) {
			dir = 'E';
		}
		else if (directionNum == 2) {
			dir = 'S';
		}
		else if (directionNum == 3) {
			dir = 'W';
		}

		if (isdigit(ch)) {//if character is number, check if number is safeDistance
			
			int steps = (int)(ch - '0');
			
			if (isdigit(plan.at(i + 1))) { //if more than one digit, cast values to integers; calculate step number
				steps *= 10;
				steps += (int)(plan.at(i + 1) - '0');
				skip++; //skip the next integer because it has been accounted for (e.g. if the plan portion is 12E, we don't want to move 12 + 2 steps.)
			}			

			int safeSteps = determineSafeDistance(newR, newC, dir, steps);

			if (safeSteps < steps) { //if not a safe distance, return 3
				if (safeSteps < 0) {
					safeSteps = 0;
				}
				nsteps += safeSteps;

				
				return 3;
			}
			else {
				nsteps += steps; //if SAFE, add number of steps
				//cout << nsteps << endl; -------------TESTING

				//upate position coordinates
				if (dir == 'E') {
					newC += steps;
				}
				else if (dir == 'W') {
					newC -= steps;
				}
				else if (dir == 'S') {
					newR += steps;
				}
				else {
					newR -= steps;
				}
			}
		}
	}


	if (newR == er && newC == ec) { //
		return 0; //plan is completed without illegal moves. car ends up at (er, ec); no problems
	}
	else {
		//cout << newR << ", " << newC << endl;
		return 1; //plan is completed without illegal moves, but ending spot does not end at er, ec
	}
}


int main(){
	setSize(15, 15);      // make a 15 by 15 grid
	setWall(12, 4);      // put a wall at (12,4)
	setWall(7, 7);      // put a wall at (7,7)
	setWall(10, 11);   // put a wall at (10,11)



	assert(hasCorrectForm(""));
	assert(hasCorrectForm("2R1r"));
	assert(hasCorrectForm("2R1L"));
	assert(!hasCorrectForm("1Lx"));
	assert(!hasCorrectForm("234r"));

	assert(determineSafeDistance(12, 4, 'N', 2) == -1);
	assert(determineSafeDistance(20, 400, 'N', 2) == -1);
	assert(determineSafeDistance(12, 2, 'Y', 2) == -1);
	assert(determineSafeDistance(12, 2, 'N', -5) == -1);
	assert(determineSafeDistance(6, 6, 'N', 3) == 3);
	assert(determineSafeDistance(6, 6, 'n', 3) == 3);
	assert(determineSafeDistance(6, 6, 'E', 3) == 3);
	assert(determineSafeDistance(6, 6, 'e', 3) == 3);
	assert(determineSafeDistance(6, 6, 'S', 3) == 3);
	assert(determineSafeDistance(6, 6, 's', 3) == 3);
	assert(determineSafeDistance(6, 6, 'W', 3) == 3);
	assert(determineSafeDistance(6, 6, 'w', 3) == 3);
	assert(determineSafeDistance(6, 7, 's', 3) == 0);
	assert(determineSafeDistance(5, 7, 's', 3) == 1);
	assert(determineSafeDistance(6, 6, 'w', 20) == 5);

	
	//----------------------------TEST obeyPlan-----------------------------------------
	int len;

	len = -999;
	assert(obeyPlan(12, 4, 3, 4, 'S', "LL2R2r2L1R", len) == 2 && len == -999);
	len = -999;
	assert(obeyPlan(8, 6, 7, 7, 'N', "1R3R", len) == 2 && len == -999);
	len = -999;
	assert(obeyPlan(80, 6, 7, 7, 'N', "1R3R", len) == 2 && len == -999);
	len = -999;
	assert(obeyPlan(8, 6, 30, 7, 'N', "1R3R", len) == 2 && len == -999);
	len = -999;
	assert(obeyPlan(8, 6, 7, 7, 'N', "1R1233R", len) == 2 && len == -999);
	len = -999;
	assert(obeyPlan(8, 6, 7, 7, 'N', "1R1x2R", len) == 2 && len == -999);
	len = -999;
	assert(obeyPlan(1, 1, 2, 4, 'N', "1R3r2rr", len) == 3 && len == 0);
	len = -999;
	assert(obeyPlan(1, 13, 1, 14, 'E', "3RR2r", len) == 3 && len == 2);
	len = -999;
	assert(obeyPlan(13, 1, 14, 1, 'S', "3RR2r", len) == 3 && len == 2);
	len = -999;
	assert(obeyPlan(1, 13, 1, 14, 'w', "13RR14r", len) == 3 && len == 12);
	len = -999;
	assert(obeyPlan(1, 1, 1, 1, 'E', "", len) == 0 && len == 0);
	len = -999;
	assert(obeyPlan(1, 1, 1, 1, 'E', "rlrlrl", len) == 0 && len == 0);
	len = -999;
	assert(obeyPlan(5, 3, 11, 11, 'E', "7r6L1Rl", len) == 0 && len == 14);
	len = -999;
	assert(obeyPlan(5, 3, 13, 11, 'E', "7r6L1Rl", len) == 1 && len == 14);
	len = -999;
	assert(obeyPlan(1, 1, 13, 1, 'E', "", len) == 1 && len == 0);
	len = -999;
	assert(obeyPlan(1, 1, 15, 1, 'E', "rlrlrl", len) == 1 && len == 0);
	len = -999;

	
	cerr << "All tests succeeded" << endl;
}